function P = UpdateP(P,Ytr,W,WXb,LC,J,lambda,beta)

P = P';
WXb = WXb';
ITER = 100;
conv = zeros(1,ITER);
lr = 0.0001;
for it=1:ITER
    
    grad = J.*(P-Ytr')+lambda*(P-LC*P*W-LC'*P*W'+LC'*LC*P*W*W')+beta*(P-WXb);
    
    Pold = P;
    P = P-lr*grad;
    
    conv(it) = norm(P-Pold,'fro');
    
    if it>1
        if abs(conv(it)-conv(it-1))<0.0001*conv(it)
            break
        end
    end
    
end
P = P'; 
end


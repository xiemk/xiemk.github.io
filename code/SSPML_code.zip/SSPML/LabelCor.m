function M = LabelCor( Y )

[n,m] = size(Y);

M = zeros(m,m);

for i=1:m
    N = sum(Y(:,i)==1);
    for j=1:m
        M(i,j)=sum(Y(:,i)'*Y(:,j))/N;
    end  
end
end


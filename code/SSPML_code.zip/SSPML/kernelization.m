function Kernel = kernelization(XA, XB, ker)
% tic;
n = size(XA,1);
m = size(XB,1);
Kernel=zeros(n,m);
if(strcmp(ker.type,'RBF'))
    gamma=ker.para(1);
    for i=1:n
        Kernel(i,:)=exp(-gamma*sum((XA(i,:)-XB).^2,2)');
    end
else
    if(strcmp(ker.type,'poly'))
        for i=1:n
            for j=1:m
                gamma=ker.para(1);
                coefficient=ker.para(2);
                degree=ker.para(3);
                Kernel(i,j)=(gamma*XA(i,:)*XB(j,:)'+coefficient)^degree;
            end
        end
    else
        for i=1:n
            for j=1:m
                Kernel(i,j)=XA(i,:)*XB(j,:)';
            end
        end
    end
end
% toc;
end



clear;
addpath 'metrics'

load('data.mat');
target(target==-1)=0;
pLabels(pLabels==-1)=0;

lambda1 = 1;
lambda2 = 1;
lambda3 = 1;
lambda4 = 1;
lambda5 = 0.1;
ker.type='RBF';ker.para(1)=0.01;

kfold = 5;
ITER = 10;


ratio = 0.1;

[instance_num,N]=size(data);
idxs=crossvalind('Kfold',data(1:instance_num,N),kfold);

result = zeros(5,kfold);
for t = 1:kfold
    test_idxs = (idxs == t);
    train_idxs=~test_idxs;
    
    Xtr=data(train_idxs,:);Ytr=pLabels(train_idxs,:);Ygt = target(train_idxs,:);
    Xte=data(test_idxs,:);Yte=target(test_idxs,:);
    
    [ntr,dim] = size(Xtr);
    nte = size(Xte,1);
    nl = floor(ntr*ratio);
    nc = size(Ytr,2);
    
    rand_idxs = randperm(ntr);
    ob_idxs = rand_idxs(1:nl);
    
    J = zeros(size(Ytr'));
    J(Ytr(ob_idxs,:)'==0) = 1;
    
    P = zeros(size(Ytr));
    P(ob_idxs,:) = Ytr(ob_idxs,:);
    
    y = Ytr(ob_idxs,:);
    tmp = y'*y;
    LC = tmp./sum(tmp,2);
    LC(logical(isnan(LC)))=0;
    
    % Nomalization
    [Xtr, settings]=mapminmax(Xtr');
    Xte=mapminmax('apply',Xte',settings);
    Xtr(logical(isnan(Xtr)))=0;
    Xte(logical(isnan(Xte)))=0;
    Xtr=Xtr';
    Xte=Xte';
    
    % Kernelization
    
    Kernel = kernelization(Xtr,Xtr,ker);
    
    % Training
    
    convergence = 0;
    
    loss = zeros(1,ITER);
    W = zeros(ntr, ntr);
    WXb=zeros(size(P));
    for it = 1:ITER
        
        % Updating P
        P = UpdateP(P,Ytr,W,WXb,LC,J,lambda2,lambda3);
        
        % Updating D
        max_iter = 50;
        convg = zeros(1,max_iter);
        
        V = zeros(ntr,ntr);
        E = zeros(ntr,ntr);
        Y1 = zeros(ntr,ntr);
        Y2 = zeros(ntr,ntr);
        mu1 = 1;
        mu2 = 1;
        rho = 2;
        XTX = Xtr*Xtr';
        LYTLY = P*LC'*LC*P';
        for iter = 1:max_iter
            Wraw = V+Y1/mu1;
            What = shrinkage(Wraw, lambda5/mu1);
            
            Vhat = (lambda1*XTX+lambda2*LYTLY+mu1*eye(ntr)+mu2*eye(ntr))^(-1)*...
                (lambda1*XTX+lambda2*P*LC'*P'+mu1*What-Y1+mu2*E-Y2);
            
            Ehat = Vhat+Y2/mu2;
            Ehat(1:ntr+1:end)=0;
            
            W = What;
            V = Vhat;
            E = Ehat;
            
            Y1 = Y1+mu1*(V-W);
            Y2 = Y2+mu2*(V-E);
            
            mu1 = min(mu1*rho, 1e7);
            mu2 = min(mu2*rho, 1e7);
            
            Wdif_ratio = norm(W-V,'fro')/norm(W,'fro');
            Vdif_ratio = norm(V-E,'fro')/norm(V,'fro');
            convg(1,iter) = Wdif_ratio;
            if Wdif_ratio<1e-8 && Vdif_ratio<1e-8
                break;
            end
            
        end
        
        
        % Updating Wb
        F=1/(2*lambda4)*Kernel+1/(2*lambda3)*eye(ntr);
        bT=ones(1,ntr)*F^(-1)*P/(ones(1,ntr)*F^(-1)*ones(ntr,1));
        A=F^(-1)*(P-ones(ntr,1)*bT);
        
        WXb=1/(2*lambda4)*Kernel*A+ones(ntr,1)*bT;
        
        ob_loss = (1/2)*norm(J.*(P'-Ytr'),'fro')^2;
        wb_loss = (lambda3/2)*norm(P-WXb,'fro')^2 + (lambda4/2)*trace((1/(2*lambda4))^2*A'*Kernel*A);
        reg_loss = lambda5*norm(W,1);
        loss(it) = ob_loss+wb_loss+reg_loss;
        
        if it>1
            if abs(loss(it)-loss(it-1))<0.0001*loss(it)
                break;
            end
        end
    end
    
    % Testing
    Left=WXb;
    Right=zeros(ntr,1);
    for i=1:ntr
        temp=Left(i,:);
        [temp,index]=sort(temp);
        candidate=zeros(1,nc+1);
        candidate(1,1)=temp(1)-0.1;
        for j=1:nc-1
            candidate(1,j+1)=(temp(j)+temp(j+1))/2;
        end
        candidate(1,nc+1)=temp(nc)+0.1;
        miss_class=zeros(1,nc+1);
        for j=1:nc+1
            temp_notlabels=index(1:j-1);
            temp_labels=index(j:nc);
            [~,false_neg]=size(setdiff(temp_notlabels,find(Ygt(i,:)==0)));
            [~,false_pos]=size(setdiff(temp_labels,find(Ygt(i,:)==1)));
            miss_class(1,j)=false_neg+false_pos;
        end
        [~,temp_index]=min(miss_class);
        Right(i,1)=candidate(1,temp_index);
    end
    Left=[Left,ones(ntr,1)];
    tempvalue=(Left\Right)';
    Weights_sizepre=tempvalue(1:nc);
    Bias_sizepre=tempvalue(nc+1);
    
    kernel = kernelization(Xte,Xtr,ker);
    Outputs=1/(2*lambda4)*kernel*A+ones(nte,1)*bT;
    Threshold=([Outputs,ones(nte,1)]*[Weights_sizepre,Bias_sizepre]')';
    Pre_Labels=zeros(nte,nc);
    for i=1:nte
        for j=1:nc
            if(Outputs(i,j)>=Threshold(1,i))
                Pre_Labels(i,j)=1;
            else
                Pre_Labels(i,j)=0;
            end
        end
    end
end

function z = shrinkage(x, kappa)
z = max( 0, x - kappa ) - max( 0, -x - kappa );

end








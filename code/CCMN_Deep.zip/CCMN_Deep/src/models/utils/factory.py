import logging

logger = logging.getLogger(__name__)

from ..tresnet import TResnetM, TResnetL, TResnetXL


def create_model(args):
    """Create a model
    """
    model_params = {'args': args, 'num_classes': args.nc}
    args = model_params['args']
    args.mo = args.mo.lower()

    if args.mo=='tresnet_m':
        model = TResnetM(model_params)
    elif args.mo=='tresnet_l':
        model = TResnetL(model_params)
    elif args.mo=='tresnet_xl':
        model = TResnetXL(model_params)
    else:
        print("model: {} not found !!".format(args.mo))
        exit(-1)

    return model

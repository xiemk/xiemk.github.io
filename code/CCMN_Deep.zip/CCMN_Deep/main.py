import os
import argparse
import torch
import random
import numpy as np
import torch.nn.parallel
import torch.optim
import torch.utils.data.distributed
import torchvision.transforms as transforms

from src.helper_functions.helper_functions import  CutoutPIL
from src.models import create_model
from randaugment import RandAugment

from tensorboardX import SummaryWriter

from utils_data import get_VOC2007, generate_noisy_labels, VOC2007_handler, VOC2007_handler_aug

from utils_algo import UnbiasedEST, BiasedEST

parser = argparse.ArgumentParser(description='CCMN VOC Training')
parser.add_argument('-me', help='specify a method', default='UnbiasedReLUAug', type=str, choices=['UnbiasedReLUAug','UnbiasedReLU','Unbiased','Biased'], required=False)
parser.add_argument('-dp', help='path to dataset', default='/home/algroup/sunfeng/data/voc')
parser.add_argument('-lr', help='learning rate', default=1e-4, type=float)
parser.add_argument('-wd', help='weight decay', default=1e-4, type=float)
parser.add_argument('-mo', help='specify a model', default='tresnet_m')
parser.add_argument('-mp', help='path to pre-trained model', default='./models_local', type=str)
parser.add_argument('-ms', help='image size', default=224, type=int)
parser.add_argument('-nc', help='number of classes', default=20)
parser.add_argument('-nw', help='number of data loading workers (default: 16)', default=8, type=int)
parser.add_argument('-bs', help='batch size', default=64, type=int)
parser.add_argument('-ep', help='number of epoches', default=40, type=int) 
parser.add_argument('-es', help='early stop', default=40, type=int)
parser.add_argument('-relu', help='negative risk correction', default=True, type=bool) 
parser.add_argument('-aug',  help='using augmentation', default=True, type=bool)      
parser.add_argument('-nr', help='noise rate', type=float, default=[0.4,0.2])
parser.add_argument('-gpu', help='id of gpu', type=int, default=0)

args = parser.parse_args()
args.do_bottleneck_head = False

torch.cuda.set_device(args.gpu)
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

seed = 1

torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)
np.random.seed(seed)
random.seed(seed)
torch.backends.cudnn.deterministic = True

dir_path = str(int(args.nr[0]*10))+str(int(args.nr[1]*10))
if not os.path.exists('./log/' + dir_path):
    os.makedirs('./log/' + dir_path)

file_path = os.path.join(dir_path, '%s_%s_%s_%s_%s'%(args.me, args.mo,str(args.lr), str(args.bs),args.ep))
Writer = SummaryWriter(log_dir='./log/'+file_path)
Save_file = './log/' + file_path + '/log.mat'

if not os.path.exists('models/%s/nr_%s_%s'%(args.me, args.nr[0], args.nr[1])):
    os.makedirs('models/%s/nr_%s_%s'%(args.me, args.nr[0], args.nr[1]))

def main():

    # Setup model
    print('creating model...')
    model = create_model(args)
    model = model.to(DEVICE)

    if args.mp:  # make sure to load pretrained ImageNet model
        state = torch.load(os.path.join(args.mp,args.mo)+'.pth', map_location='cpu')
        filtered_dict = {k: v for k, v in state['model'].items() if
                         (k in model.state_dict() and 'head.fc' not in k)}
        print(len(filtered_dict))
        model.load_state_dict(filtered_dict, strict=False)


    print('done\n')

    # VOC Data loading
    train_transform_aug = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.Resize((args.ms, args.ms)),
        CutoutPIL(cutout_factor=0.5),
        RandAugment(),
        transforms.ToTensor()])

    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.Resize((args.ms, args.ms)),
        transforms.ToTensor()])
    
    test_transform = transforms.Compose([
        transforms.Resize((args.ms, args.ms)),
        transforms.ToTensor()])
    
    data_path_val   = f'{args.dp}/VOCtest2007/VOCdevkit/VOC2007'    
    data_path_train = f'{args.dp}/VOCtrainval2007/VOCdevkit/VOC2007' 

    train_images, train_labels, test_images, test_labels = get_VOC2007(data_path_train, data_path_val)
    train_noisy_labels = generate_noisy_labels(train_labels, noise_rate=args.nr)
    train_dataset = VOC2007_handler_aug(train_images, train_noisy_labels, data_path_train,transform=train_transform, transform_aug=train_transform_aug)
    test_dataset = VOC2007_handler(test_images, test_labels, data_path_val, transform=test_transform)

    print("len(val_dataset): ", len(test_dataset))
    print("len(train_dataset): ", len(train_dataset))
    
    # Data loading
    train_loader = torch.utils.data.DataLoader(
        train_dataset, batch_size=args.bs, shuffle=True,
        num_workers=args.nw, pin_memory=True)

    test_loader = torch.utils.data.DataLoader(
        test_dataset, batch_size=args.bs, shuffle=False,
        num_workers=args.nw, pin_memory=False)

    # Training
    if args.me == 'UnbiasedReLUAug':
        args.relu = args.aug =True
        UnbiasedEST(model, train_loader, test_loader, args, Writer)
    elif args.me == 'UnbiasedReLU':
        args.relu = True
        UnbiasedEST(model, train_loader, test_loader, args, Writer)
    elif args.me == 'Unbiased':
        UnbiasedEST(model, train_loader, test_loader, args, Writer)
    elif args.me == 'Biased':
        BiasedEST(model, train_loader, test_loader, args, Writer)
    

if __name__ == '__main__':
    main()

Pytorch implementation (deep version) for "CCMN: A General Framework for Learning with Class-Conditional Multi-Label Noise" (TPAMI).
This repository was implemented by Ming-Kun Xie (mkxie@nuaa.edu.cn).

Requirements:
Numpy
Pytorch
Torhvision

-dp: path to dataset
-me: specifies the method
-mo: specifies the model 
-lr: learning rate
-wd: weight decay
-ep: total number of epoches
-relu: negative loss correction
-aug: augmentation for training images

Running:

python main.py -me UnbiasedReLUAug -mo tresnet_m -lr 1e-4 -ep 40 -relu True -aug True

If there exists any problem, please mail mkxie@nuaa.edu.cn. 
Thank you!

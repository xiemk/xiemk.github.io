import os
import torch
import random
import numpy as np
from PIL import Image
import xml.etree.ElementTree as ET
from torch.utils.data.dataset import Dataset

class VOC2007_handler(Dataset):
	def __init__(self, X, Y, data_path, transform=None, random_crops=0):
		self.X = X
		self.Y = Y
		self.transform = transform
		self.random_crops = random_crops
		self.data_path = data_path

	def __getitem__(self, index):
		x = Image.open(self.data_path + '/JPEGImages/' + self.X[index] + '.jpg').convert('RGB')

		if self.random_crops == 0:
			x = self.transform(x)
		else:
			crops = []
			for i in range(self.random_crops):
				crops.append(self.transform(x))
			x = torch.stack(crops)
        
		y = self.Y[index]

		return x, y, index

	def __len__(self):
		return len(self.X)

class VOC2007_handler_aug(Dataset):
	def __init__(self, X, Y, data_path, transform=None, transform_aug=None, random_crops=0):
		self.X = X
		self.Y = Y
		self.transform = transform
		self.transform_aug = transform_aug
		self.random_crops = random_crops
		self.data_path = data_path

	def __getitem__(self, index):
		x_ = Image.open(self.data_path + '/JPEGImages/' + self.X[index] + '.jpg').convert('RGB')

		if self.random_crops == 0:
			x = self.transform(x_)
			x_aug = self.transform_aug(x_)
		else:
			crops = []
			for i in range(self.random_crops):
				crops.append(self.transform(x))
			x = torch.stack(crops)
        
		y = self.Y[index]

		return x, x_aug, y, index

	def __len__(self):
		return len(self.X)


def __dataset_info(data_path,trainval):
	classes = ('__background__','aeroplane', 'bicycle', 'bird', 'boat',
						'bottle', 'bus', 'car', 'cat', 'chair',
						'cow', 'diningtable', 'dog', 'horse',
						'motorbike', 'person', 'pottedplant',
						'sheep', 'sofa', 'train', 'tvmonitor')
	num_classes  = len(classes)
	class_to_ind = dict(zip(classes, range(num_classes)))

	with open(data_path+'/ImageSets/Main/'+trainval+'.txt') as f:
		annotations = f.readlines()
	
	annotations = [n[:-1] for n in annotations]
	names  = []
	labels = []
	for af in annotations:
		if len(af)!=6:
			continue
		filename = os.path.join(data_path,'Annotations',af)
		tree = ET.parse(filename+'.xml')
		objs = tree.findall('object')
		num_objs = len(objs)
		
		boxes_cl = np.zeros((num_objs), dtype=np.int32)
		
		for ix, obj in enumerate(objs):
			cls = class_to_ind[obj.find('name').text.lower().strip()]
			boxes_cl[ix] = cls
		
		lbl = np.zeros(num_classes)
		lbl[boxes_cl] = 1
		labels.append(lbl)
		names.append(af)
	
	labels = np.array(labels).astype(np.float32)
	labels = labels [:, 1:]
	
	return np.array(names), np.array(labels)

def get_VOC2007(train_data_path, test_data_path):
  
	train_data, train_labels = __dataset_info(train_data_path,'trainval')
	train_idx = np.arange(train_labels.shape[0])
	np.random.shuffle(train_idx)
	train_data, train_labels = train_data[train_idx], train_labels[train_idx]

	test_data, test_labels = __dataset_info(test_data_path,'test')
	test_idx = np.arange(test_labels.shape[0])
	np.random.shuffle(test_idx)
	test_data, test_labels = test_data[test_idx], test_labels[test_idx]
	
	return train_data, train_labels, test_data, test_labels

def generate_noisy_labels(labels, noise_rate=0.2):

	N, C = labels.shape

	if isinstance(noise_rate,list):
		rand_mat = np.random.rand(N,C)
		mask = np.zeros((N,C), dtype = np.float)
		mask[labels!=1]= rand_mat[labels!=1]<noise_rate[0]
		mask[labels==1]= rand_mat[labels==1]<noise_rate[1]
		noisy_labels = np.copy(labels)

		noisy_labels[mask==1] = 1-noisy_labels[mask==1]

	# else:
	# 	rand_mat = np.random.rand(N,C)
	# 	mask = np.zeros((N,C), dtype = np.float)
	# 	for j in range(K):
	# 		yj = labels[:,j]
	# 		mask[yj!=1,j] = rand_mat[yj!=1,j]<nr_set[0,j]
	# 		mask[yj==1,j] = rand_mat[yj==1,j]<nr_set[1,j]
	# 	noisy_labels = np.copy(labels)
	# 	noisy_labels[mask==1] = -noisy_labels[mask==1]

	return noisy_labels
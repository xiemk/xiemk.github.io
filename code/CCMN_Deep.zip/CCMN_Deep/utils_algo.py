import os
import models
import torch
from torch.optim import lr_scheduler
from torch.cuda.amp import GradScaler, autocast
from src.helper_functions.helper_functions import mAP, CocoDetection, CutoutPIL, ModelEma, add_weight_decay
from scipy.io import savemat

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def UnbiasedEST(model, train_loader, val_loader, args, Writer):
    ema = ModelEma(model, 0.9997)  # 0.9997^641=0.82

    relu = args.relu
    aug = args.aug
    noise_rate = args.nr
    # set optimizer
    lr = args.lr
    Epochs = args.ep
    Stop_epoch = args.es
    weight_decay = args.wd
    parameters = add_weight_decay(model, weight_decay)
    optimizer = torch.optim.Adam(params=parameters, lr=lr, weight_decay=0)  # true wd, filter_bias_and_bn
    steps_per_epoch = len(train_loader)
    scheduler = lr_scheduler.OneCycleLR(optimizer, max_lr=lr, steps_per_epoch=steps_per_epoch, epochs=Epochs,
                                        pct_start=0.2)

    mAP_bar = 0.0
    ema_mAP_bar = 0.0
    trainInfoList = []
    scaler = GradScaler()
    for epoch in range(Epochs):
        if epoch > Stop_epoch:
            break

        model.train()

        for i, (img, img_aug,  target, ind) in enumerate(train_loader):

            if aug:
                img_ = img_aug.to(DEVICE)
            else:
                img_ = img.to(DEVICE)
            target = target.to(DEVICE)

            with autocast():  # mixed precision
                output = model(img_).float()  # sigmoid will be done in loss !

            loss = compute_ub_loss(output, target,noise_rate,relu)
            model.zero_grad()

            scaler.scale(loss).backward()
            # loss.backward()

            scaler.step(optimizer)
            scaler.update()
            # optimizer.step()

            scheduler.step()

            ema.update(model)
            # store information
            if i % 20 == 0:
                trainInfoList.append([epoch, i, loss.item()])
                print('Epoch [{}/{}], Step [{}/{}], LR {:.1e}, Loss: {:.1f}'
                      .format(epoch, Epochs, str(i).zfill(3), str(steps_per_epoch).zfill(3),
                              scheduler.get_last_lr()[0], \
                              loss.item()))

        model.eval()
        mAP_score, mAP_score_ema = validate_multi(val_loader, model, ema)
        model.train()

        if mAP_score > mAP_bar:
            mAP_bar = mAP_score
            torch.save(model.state_dict(), os.path.join(
                    'models/%s/nr_%s_%s/%s_%s_%s_%s.pth'%(args.me, noise_rate[0],noise_rate[1], args.mo, str(args.lr), str(args.bs), str(args.ep))))
        
        if mAP_score_ema > ema_mAP_bar:
            ema_mAP_bar = mAP_score_ema
            torch.save(model.state_dict(), os.path.join(
                    'models/%s/nr_%s_%s/%s_%s_%s_%s_ema.pth'%(args.me, noise_rate[0],noise_rate[1], args.mo, str(args.lr), str(args.bs), str(args.ep))))

        print('current_mAP = {:.2f}, highest_mAP = {:.2f}\n'.format(max(mAP_score,mAP_score_ema), max(mAP_bar,ema_mAP_bar)))

        Writer.add_scalar('mAP', mAP_score, epoch)
        Writer.add_scalar('mAP_ema', mAP_score_ema, epoch)

def BiasedEST(model, train_loader, val_loader, args, Writer):
    ema = ModelEma(model, 0.9997)  # 0.9997^641=0.82

    noise_rate = args.nr
    # set optimizer
    lr = args.lr
    Epochs = args.ep
    Stop_epoch = args.es
    weight_decay = args.wd
    parameters = add_weight_decay(model, weight_decay)
    optimizer = torch.optim.Adam(params=parameters, lr=lr, weight_decay=0)  # true wd, filter_bias_and_bn
    steps_per_epoch = len(train_loader)
    scheduler = lr_scheduler.OneCycleLR(optimizer, max_lr=lr, steps_per_epoch=steps_per_epoch, epochs=Epochs,
                                        pct_start=0.2)

    criterion = torch.nn.BCEWithLogitsLoss()

    trainInfoList = []
    mAP_bar = 0.0
    ema_mAP_bar = 0.0
    scaler = GradScaler()
    for epoch in range(Epochs):
        if epoch > Stop_epoch:
            break

        model.train()

        for i, (inputData, _,  target, ind) in enumerate(train_loader):
            inputData = inputData.to(DEVICE)
            target = target.to(DEVICE)

            with autocast():  # mixed precision
                output = model(inputData).float()  # sigmoid will be done in loss !

            loss = criterion(output, target)
            model.zero_grad()

            scaler.scale(loss).backward()
            # loss.backward()

            scaler.step(optimizer)
            scaler.update()
            # optimizer.step()

            scheduler.step()

            ema.update(model)
            # store information
            if i % 20 == 0:
                trainInfoList.append([epoch, i, loss.item()])
                print('Epoch [{}/{}], Step [{}/{}], LR {:.1e}, Loss: {:.1f}'
                      .format(epoch, Epochs, str(i).zfill(3), str(steps_per_epoch).zfill(3),
                              scheduler.get_last_lr()[0], \
                              loss.item()))

        model.eval()
        mAP_score, mAP_score_ema = validate_multi(val_loader, model, ema)
        model.train()
        if mAP_score > mAP_bar:
            mAP_bar = mAP_score
            torch.save(model.state_dict(), os.path.join(
                    'models/%s/nr_%s_%s/%s_%s_%s_%s.pth'%(args.me, noise_rate[0],noise_rate[1], args.mo, str(args.lr), str(args.bs), str(args.ep))))
        
        if mAP_score_ema > ema_mAP_bar:
            ema_mAP_bar = mAP_score_ema
            torch.save(model.state_dict(), os.path.join(
                    'models/%s/nr_%s_%s/%s_%s_%s_%s_ema.pth'%(args.me, noise_rate[0],noise_rate[1], args.mo,str(args.lr), str(args.bs), str(args.ep))))

        print('current_mAP = {:.2f}, highest_mAP = {:.2f}\n'.format(max(mAP_score,mAP_score_ema), max(mAP_bar,ema_mAP_bar)))

        Writer.add_scalar('mAP', mAP_score, epoch)
        Writer.add_scalar('mAP_ema', mAP_score_ema, epoch)


def compute_ub_loss(output, target, noise_rate,relu):

    criterion = torch.nn.BCEWithLogitsLoss(reduction='none')
    loss_mat_pos = criterion(output, target)
    loss_mat_neg = criterion(output, 1-target)

    if isinstance(noise_rate,list):
        neg_nr, pos_nr = noise_rate

        nr_mat_pos = torch.FloatTensor(target.size()).cuda()
        nr_mat_pos[target!=1] = neg_nr
        nr_mat_pos[target==1] = pos_nr
        nr_mat_neg = torch.FloatTensor(target.size()).cuda()
        nr_mat_neg[1-target!=1] = neg_nr
        nr_mat_neg[1-target==1] = pos_nr
        C = 1/(1-neg_nr-pos_nr)
    

    if relu:
        loss = torch.clamp(((1-nr_mat_neg).mul(loss_mat_pos)-nr_mat_pos.mul(loss_mat_neg)).mul(C).mean(), min=0.0)
    else:
        loss = ((1-nr_mat_neg).mul(loss_mat_pos)-nr_mat_pos.mul(loss_mat_neg)).mul(C).mean()

    return loss


def validate_multi(val_loader, model, ema_model):
    print("starting validation")
    Sig = torch.nn.Sigmoid()
    preds_regular = []
    preds_ema = []
    targets = []
    for i, (input, target, _) in enumerate(val_loader):
        target = target
        # target = target.max(dim=1)[0]
        # compute output
        with torch.no_grad():
            with autocast():
                output_regular = Sig(model(input.cuda())).cpu()
                output_ema = Sig(ema_model.module(input.cuda())).cpu()

        # for mAP calculation
        preds_regular.append(output_regular.cpu().detach())
        preds_ema.append(output_ema.cpu().detach())
        targets.append(target.cpu().detach())

    mAP_score_regular = mAP(torch.cat(targets).numpy(), torch.cat(preds_regular).numpy())
    mAP_score_ema = mAP(torch.cat(targets).numpy(), torch.cat(preds_ema).numpy())
    print("mAP score regular {:.2f}, mAP score EMA {:.2f}".format(mAP_score_regular, mAP_score_ema))
    return mAP_score_regular, mAP_score_ema
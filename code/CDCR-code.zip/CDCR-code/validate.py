import argparse
import time
import torch
from torch.cuda.amp.autocast_mode import autocast
import torch.nn.parallel
import torch.optim
import torch.utils.data.distributed
import torchvision.transforms as transforms
import os
import random
import torch.nn as nn

from src.helper_functions.helper_functions import mAP, AverageMeter, CocoDetection
from src.models import create_model
import numpy as np

from dataset import get_COCO2014, generate_noisy_labels, COCO2014_handler

os.environ['CUDA_VISIBLE_DEVICES'] = '2'
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

setting = 'upperbound'
best_model = './models/' + setting + '/model_tresnet_l_highest.pth'
print(setting)

parser = argparse.ArgumentParser(description='PyTorch ImageNet Training')
parser.add_argument('--data', metavar='DIR', help='path to dataset', default='./data/coco')
parser.add_argument('--model-name', default='tresnet_l')
parser.add_argument('--model-path', default='model_tresnet_l_highest.pth', type=str)
parser.add_argument('--num-classes', default=80)
parser.add_argument('-j', '--workers', default=8, type=int, metavar='N',
                    help='number of data loading workers (default: 16)')
parser.add_argument('--image-size', default=224, type=int,
                    metavar='N', help='input image size (default: 448)')
parser.add_argument('--thre', default=0.5, type=float,
                    metavar='N', help='threshold value')
parser.add_argument('-b', '--batch-size', default=128, type=int,
                    metavar='N', help='mini-batch size (default: 16)')
parser.add_argument('--print-freq', '-p', default=64, type=int,
                    metavar='N', help='print frequency (default: 64)')


seed = 1
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
np.random.seed(seed)
random.seed(seed)

def main():
    args = parser.parse_args()
    args.batch_size = args.batch_size

    # setup model
    print('creating and loading the model...')
    args.do_bottleneck_head = False
    model = create_model(args)
    model = model.to(DEVICE)

    if args.model_path:  # make sure to load pretrained ImageNet model
        state = torch.load(best_model, map_location='cpu')
        filtered_dict = {k[14:]: v for k, v in state.items() if
                         (k[14:] in model.state_dict())}
        model.load_state_dict(filtered_dict, strict=True)
    

    model.eval()
    print('done\n')

    # Data loading code
    normalize = transforms.Normalize(mean=[0, 0, 0],
                                     std=[1, 1, 1])

    test_transform = transforms.Compose([
        transforms.Resize((args.image_size, args.image_size)),
        transforms.ToTensor()])
    
    instances_path_val = os.path.join(args.data, 'val_anno.json')
    instances_path_train = os.path.join(args.data, 'train_anno.json')

    data_path_val   = f'{args.data}/val2014'    # args.data

    _, _, test_images, test_labels = get_COCO2014(instances_path_train, instances_path_val)

    test_dataset = COCO2014_handler(test_images, test_labels, data_path_val, transform=test_transform)

    print("len(val_dataset)): ", len(test_dataset))

    test_loader = torch.utils.data.DataLoader(
        test_dataset, batch_size=args.batch_size, shuffle=False,
        num_workers=args.workers, pin_memory=False)

    validate_multi(test_loader, model, args)

def validate_multi(val_loader, model, args):
    print("starting actuall validation")

    Sig = torch.nn.Sigmoid()
    preds = []
    targets = []

    for i, (input, target, _) in enumerate(val_loader):
        # comput output
        with torch.no_grad():
            with autocast():
                output = Sig(model(input.cuda()))

        # for mAP, precision, recall, f1 calculation
        preds.append(output)
        targets.append(target)

    preds = torch.cat(preds, dim=0)
    targets = torch.cat(targets, dim=0)
    confidences = Sig(preds)

    mAP_score = mAP(targets.numpy(), preds.cpu().detach().numpy())
    OP, OR, OF1, CP, CR, CF1 = precision_recall_f1(targets.numpy(), confidences.cpu().detach().numpy())

    print(setting, end=' ')
    print('mAP: {:.2f} '.format(mAP_score),
          'CP: {:.2f} CR: {:.2f} CF1: {:.2f} '.format(CP, CR, CF1),
          'OP: {:.2f} OR: {:.2f} OF1: {:.2f} '.format(OP, OR, OF1))
        
def precision_recall_f1(test_target, scores):
    '''
    Evaluate the average per-class precision (CP), recall (CR), F1 (CF1)
    and the average overall precision (OP), recall (OR), F1 (OR1)
    '''

    assert scores.shape == test_target.shape

    N, C = scores.shape

    scores_sorted =-np.sort(-scores, axis=1)
    threshold = scores_sorted[:, 2].reshape(N, -1)

    # threshold = 0.6
    pred_target = (scores >= threshold).astype(np.float64)

    N_g = np.sum(test_target, axis=0).astype(np.float64)
    N_p = np.sum(pred_target, axis=0).astype(np.float64)
    N_c = np.sum(test_target * pred_target, axis=0).astype(np.float64)

    OP = np.sum(N_c) / np.sum(N_p)
    OR = np.sum(N_c) / np.sum(N_g)
    OF1 = (2 * OP * OR) / (OP + OR)

    N_p[N_p == 0] = 1

    CP = np.sum(N_c / N_p) / C 
    CR = np.sum(N_c / N_g) / C
    CF1 = (2 * CP * CR) / (CP + CR)

    return OP * 100, OR * 100, OF1 * 100, CP * 100, CR * 100, CF1 * 100

if __name__ == '__main__':
    main()

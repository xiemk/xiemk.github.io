
import random
import os
import torch
import scipy.io as scio
import numpy as np
from torch.utils.data.dataset import Dataset
from PIL import Image

def generate_noisy_labels(labels, nr_range):
	
    N, nc = labels.shape
    
    assert isinstance(nr_range,list)
    
    assert nr_range[1]>nr_range[0]

    noise_rate = np.random.randint(10*nr_range[0],10*nr_range[1]+1,(2,nc))/10
    tmp = np.sum(noise_rate,axis=0)
    noise_rate[:,tmp==1] -= 0.1

    rand_mat = np.random.rand(N,nc)
    mask = np.zeros((N,nc), dtype = np.float)
    for j in range(nc):
        yj = labels[:,j]
        mask[yj!=1,j] = rand_mat[yj!=1,j]<noise_rate[0,j]
        mask[yj==1,j] = rand_mat[yj==1,j]<noise_rate[1,j]

    noisy_labels = np.copy(labels)
    noisy_labels[mask==1] = -noisy_labels[mask==1]

    return noisy_labels, noise_rate

def get_MLLdata(dn, path):

    data_path = f'{path}/{dn}.mat'

    data_dict = scio.loadmat(data_path)

    data = data_dict['data'].astype(np.float32)
    data = data[:, :, np.newaxis]
    labels = data_dict['target']
    
    ntr = 0.6
    nte = 0.4

    n = len(data)

    idxs = np.arange(n)
    np.random.shuffle(idxs)

    train_idxs = idxs[:int(n*ntr)]
    test_idxs = idxs[int(n*ntr):]

    dim = data.shape[1]
    nc = labels.shape[1]

    train_data = data[train_idxs]
    train_labels = labels[train_idxs]

    test_data = data[test_idxs]
    test_labels = labels[test_idxs]


    return train_data, train_labels, test_data, test_labels, nc, dim


def get_MultiMNIST(dn, path):

	data_path = f'{path}/{dn}'

	X = []
	Y = []
	for i in range (50):
		
		tmp = random.sample(range(10),2)
		fn = str(tmp[0])+str(tmp[1])
		
		imgs = []
		img_root = os.path.join(data_path, fn)
		for img in os.listdir(img_root):
			imgs.append(os.path.join(img_root, img))

		imgs_np = np.array(imgs)
		X.append(imgs_np[:200])
		label_mat = np.zeros((200,10))
		label_mat[:,tmp]=1
		Y.append(label_mat)

	X = np.concatenate(X)
	Y = np.concatenate(Y)

	rand_idxs = np.random.permutation(X.shape[0])

	X = X[rand_idxs]
	Y = Y[rand_idxs,:]
	Y[Y==0] = -1

	train_data = X[:6000]
	train_labels = Y[:6000]
	test_data = X[6000:]
	test_labels = Y[6000:]

	np.random.seed()
	random.seed()

	return train_data, train_labels, test_data, test_labels


class MLL_handler(Dataset):
    def __init__(self, X, Y, transform=None):
        self.X = X
        self.Y = Y
        self.transform = transform

    def __getitem__(self, index):
        x, y= self.X[index], self.Y[index]


        if self.transform is not None:
            x = self.transform(x)

        return x, y
    def __len__(self):
        return len(self.X)

class MultiMNIST_handler(Dataset):
	def __init__(self, X, Y, transform=None):
		self.X = X
		self.Y = Y
		self.transform = transform

	def __getitem__(self, index):
		img_path, y= self.X[index], self.Y[index]

		img = Image.open(img_path)
		if self.transform is not None:
			x = self.transform(img)

		return x, y
	def __len__(self):
		return len(self.X)
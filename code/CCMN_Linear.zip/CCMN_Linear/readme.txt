Pytorch implementation for "CCMN: A General Framework for Learning with Class-Conditional Multi-Label Noise" (TPAMI).
This repository was implemented by Ming-Kun Xie (mkxie@nuaa.edu.cn).

Requirements:
Numpy
Pytorch
Torhvision
Sklearn

-dn: specifies the dataset
-me: specifies the method
-mo: specifies the model 
-lo: specifies the loss function (default: hinge loss)
-lr: learning rate
-wd: weight decay
-ep: total number of epoches

Running:

python main.py -dn music_emotion -me HLUnbiased -lo hinge -ep 200 -mo linear -lr 1e-2 -bs 400
python main.py -dn mirflickr -me HLUnbiased -lo hinge -ep 200 -mo linear -lr 1e-2 -bs 400
python main.py -dn tmc -me HLUnbiased -lo hinge -ep 200 -mo linear -lr 1e-2 -bs 800
python main.py -dn DoubleMNIST -me HLUnbiased -lo hinge -ep 100 -mo linear -lr 1e-3 -bs 200

Note: traditional multi-label datasets must be normalized on features before using the codes.

If there exists any problem, please mail mkxie@nuaa.edu.cn. 
Thank you!

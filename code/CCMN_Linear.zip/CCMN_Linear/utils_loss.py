
import numpy as np
import torch
import torch.nn as nn

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def hinge_loss(output, labels):

    z = labels.mul(output)

    loss = torch.clamp(1-z, min = 0.0)
    
    return loss

def sigmoid_loss(output,labels):

    loss_func = nn.Sigmoid()

    z = labels.mul(output)
    
    loss = loss_func(-z)


    return loss

def square_loss(output,labels):

    loss_func = nn.MSELoss(reduction='none')
    z = labels.mul(output)
    one_mat = torch.ones(z.size()).cuda()
    loss = loss_func(one_mat, z)

    return loss

def hl_ub_loss(output, target, loss_func, noise_rate, relu):


    loss_mat_pos = loss_func(output, target)
    loss_mat_neg = loss_func(output, -target)

    nr_mat_pos = torch.FloatTensor(target.size()).cuda()
    nr_mat_neg = torch.FloatTensor(target.size()).cuda()
    C = torch.FloatTensor(target.size()).cuda()
    for j in range(target.size(1)):
        yj = target[:,j]
        nr_mat_pos[yj!=1,j] = noise_rate[0,j]
        nr_mat_pos[yj==1,j] = noise_rate[1,j]
        nr_mat_neg[-yj!=1,j] = noise_rate[0,j]
        nr_mat_neg[-yj==1,j] = noise_rate[1,j]
        C[:,j] = 1/(1-noise_rate[0,j]-noise_rate[1,j])
    

    if relu:
        loss = torch.clamp(((1-nr_mat_neg).mul(loss_mat_pos)-nr_mat_pos.mul(loss_mat_neg)).mul(C).mean(), min=0.0)
    else:
        loss = ((1-nr_mat_neg).mul(loss_mat_pos)-nr_mat_pos.mul(loss_mat_neg)).mul(C).mean()

    return loss


def rl_ub_loss(output, target, loss_func, noise_rate, relu):

    nc = target.size(1)
    loss = 0.0
    for t in range(nc-1):
                
        ft = output[:,t].view(len(output),1)
        frest = output[:,t+1:-1]
        yt = target[:,t].view(len(target),1)
        yrest = target[:,t+1:]
        y_diff = (yt-yrest)/2
        
        f_diff = ft-frest

        nr_neg_j = noise_rate[0,t]
        nr_pos_j = noise_rate[1,t]
        alpha_j = 1-nr_pos_j
        beta_j = 1-nr_neg_j

        nr_neg_t = torch.from_numpy(noise_rate[0,t+1:].reshape(1,y_diff.shape[1])).cuda()
        nr_pos_t = torch.from_numpy(noise_rate[1,t+1:].reshape(1,y_diff.shape[1])).cuda()
        beta_t = 1-nr_neg_t
        alpha_t = 1-nr_pos_t

        factor = (1-nr_pos_j-nr_neg_j)*(1-nr_pos_t-nr_neg_t)
        
        
        loss_pos = loss_func(f_diff,torch.ones(y_diff.size()).cuda())
        loss_neg = loss_func(f_diff,-1*torch.ones(y_diff.size()).cuda())
        
        loss_mat = beta_j*alpha_t.mul(loss_pos)+nr_pos_j*nr_neg_t.mul(loss_neg)
        loss_mat_neg = nr_neg_j*nr_pos_t.mul(loss_pos)+alpha_j*beta_t.mul(loss_neg)


        loss_mat[y_diff==-1] = loss_mat_neg[y_diff==-1]

        idxs = (y_diff==0)&(yrest==1)
        loss_mat_pos_pos = -beta_j*nr_pos_t.mul(loss_pos)-nr_pos_j*beta_t.mul(loss_neg)
        loss_mat[idxs] = loss_mat_pos_pos[idxs]
        
        idxs = (y_diff==0)&(yrest==-1)
        loss_mat_neg_neg = -nr_neg_j*alpha_t.mul(loss_pos)-alpha_j*nr_neg_t.mul(loss_neg)
        loss_mat[idxs] = loss_mat_neg_neg[idxs]

        loss += torch.div(loss_mat,factor).mean()

        ft = output[:,:-1]
        f0 = output[:,-1].view(ft.size(0),1)
        yt = target
        y0 = torch.from_numpy(np.zeros((yt.size(0),1),dtype=np.float32)).to(DEVICE)


        y_diff = yt-y0
        f_diff = ft-f0

        loss_mat_pos = loss_func(f_diff, y_diff)
        loss_mat_neg = loss_func(f_diff, -y_diff) 

        nr_mat_pos = torch.FloatTensor(y_diff.size()).cuda()
        nr_mat_neg = torch.FloatTensor(y_diff.size()).cuda()
        factor = torch.FloatTensor(y_diff.size()).cuda()
        for j in range(y_diff.shape[1]):
            yj = y_diff[:,j]
            nr_mat_pos[yj!=1,j] = noise_rate[0,j]
            nr_mat_pos[yj==1,j] = noise_rate[1,j]
            nr_mat_neg[-yj!=1,j] = noise_rate[0,j]
            nr_mat_neg[-yj==1,j] = noise_rate[1,j]
            factor[:,j] = 1/(1-noise_rate[0,j]-noise_rate[1,j])


        loss_mat = ((1-nr_mat_neg).mul(loss_mat_pos)-nr_mat_pos.mul(loss_mat_neg)).mul(factor)

        loss += loss_mat.mean()

    if relu:
        loss = torch.clamp(loss/(nc-1), min=0.0)
    else:
        loss /= (nc-1)

    return loss

def rl_biased_loss(output, target, loss_func):
    
    N, nc = target.shape
    loss = 0.0
    for t in range(nc-1):
        ft = output[:,t].view(N,1)
        frest = output[:,t+1:]
        yt = target[:,t].view(N,1)
        yrest = target[:,t+1:]
        y_diff = (yt-yrest)/2

        loss += loss_func(ft-frest, y_diff).mean()

    
    return loss/(nc-1)
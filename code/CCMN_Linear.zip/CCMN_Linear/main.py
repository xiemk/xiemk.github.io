import os
import argparse

import torch
import random
import numpy as np
import torch.nn.parallel
import torch.optim
import torch.utils.data.distributed
import torchvision.transforms as transforms

from models import create_model
from utils_data import get_MLLdata, get_MultiMNIST, MLL_handler, MultiMNIST_handler, generate_noisy_labels
from utils_loss import hinge_loss, sigmoid_loss, square_loss
from utils_algo import HLUnbiasedEST, RLUnbiasedEST, HLBiasedEST, RLBiasedEST

from tensorboardX import SummaryWriter


os.environ['CUDA_VISIBLE_DEVICES'] = '0'
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

parser = argparse.ArgumentParser(description='CCMN')
parser.add_argument('-me', help='specify a method', default='HLUnbiased', type=str, 
choices=['HLUnbiasedReLU','RLUnbiasedReLU','HLUnbiased','RLUnbiased','HLBiased','RLBiased'], required=False)
parser.add_argument('-dn', help='data', default='music_style')
parser.add_argument('-dp', help='path to dataset', default='./data')
parser.add_argument('-lr', help='learning rate', default=1e-2, type=float)
parser.add_argument('-wd', help='weight decay', default=1e-4, type=float)
parser.add_argument('-mo', help='specify a model', default='linear', choices=['linear', 'mlp'])
parser.add_argument('-lo', help='specify a loss function', default='sigmoid')
parser.add_argument('-hdim', help='hidden dim of mlp', default=256)
parser.add_argument('-nw', help='number of data loading workers (default: 16)', default=8, type=int)
parser.add_argument('-bs', help='batch size', default=400, type=int)
parser.add_argument('-ep', help='number of epoches', default=100, type=int)
parser.add_argument('-relu', help='negative risk correction', default=False, type=bool) 
parser.add_argument('-ra', help='the range of noise rate', type=float, default=[0.1,0.5])


seed = 0
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
np.random.seed(seed)
random.seed(seed)


args = parser.parse_args()
args.do_bottleneck_head = False

if not os.path.exists('./log/' + args.me):
    os.makedirs('./log/' + args.me)

Writer = SummaryWriter(log_dir='./log/' + args.me)
Save_file = './log/' + args.me + '/log.mat'

if not os.path.exists('models/%s/nr_%s_%s'%(args.me, args.ra[0], args.ra[1])):
    os.makedirs('models/%s/nr_%s_%s'%(args.me, args.ra[0], args.ra[1]))

if args.lo == 'hinge':
    loss_func = hinge_loss
elif args.lo == 'sigmoid':
    loss_func = sigmoid_loss
elif args.lo == 'square':
    loss_func = square_loss

def main():

    # Data loading
    train_transform = transforms.Compose([transforms.ToTensor()])
    
    test_transform = transforms.Compose([transforms.ToTensor()])

    if args.dn in ['DoubleMNIST','DoubleKMNIST','DoubleFMNIST']:
        train_data, train_labels, test_data, test_labels = get_MultiMNIST(args.dn, args.dp)
        handler = MultiMNIST_handler
        nc = 10
        dim = 64*64
    else:
        train_data, train_labels, test_data, test_labels, nc, dim = get_MLLdata(args.dn, args.dp)
        handler = MLL_handler
        
    train_noisy_labels, noise_rate = generate_noisy_labels(train_labels, nr_range=args.ra)   
    train_dataset = handler(train_data, train_noisy_labels, train_transform)
    test_dataset = handler(test_data, test_labels, test_transform)

    

    print(noise_rate)

    args.nr = noise_rate
    args.nc = nc
    args.dim = dim
    
    # Setup model
    print('creating model...')
    model = create_model(args)
    model = model.to(DEVICE)
    
    print('done\n')

    print("len(test_dataset): ", len(test_dataset))
    print("len(train_dataset): ", len(train_dataset))
    
    # Pytorch Data loader
    train_loader = torch.utils.data.DataLoader(
        train_dataset, batch_size=args.bs, shuffle=True,
        num_workers=args.nw, pin_memory=True)

    test_loader = torch.utils.data.DataLoader(
        test_dataset, batch_size=args.bs, shuffle=False,
        num_workers=args.nw, pin_memory=False)

    # Actuall Training
    if args.me == 'HLUnbiasedReLU':
        args.relu = True
        HLUnbiasedEST(model, train_loader, test_loader, loss_func, args, Writer)
    elif args.me == 'RLUnbiasedReLU':
        args.relu = True
        RLUnbiasedEST(model, train_loader, test_loader, loss_func, args, Writer)
    elif args.me == 'HLUnbiased':
        HLUnbiasedEST(model, train_loader, test_loader, loss_func, args, Writer)
    elif args.me == 'RLUnbiased':
        RLUnbiasedEST(model, train_loader, test_loader, loss_func, args, Writer)
    elif args.me == 'HLBiased':
        HLBiasedEST(model, train_loader, test_loader, loss_func, args, Writer)
    elif args.me == 'RLBiased':
        RLBiasedEST(model, train_loader, test_loader, loss_func, args, Writer)
    

if __name__ == '__main__':
    main()

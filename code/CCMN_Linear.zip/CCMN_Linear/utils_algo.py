
import os
import torch
import numpy as np
from sklearn.metrics import hamming_loss, label_ranking_loss, coverage_error, label_ranking_average_precision_score
from utils_loss import hl_ub_loss, rl_ub_loss, rl_biased_loss

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def HLUnbiasedEST(model, train_loader, val_loader, loss_func, args, Writer):

    relu = args.relu
    noise_rate = args.nr
    me = args.me
    # set optimizer
    lr = args.lr
    Epochs = args.ep
    weight_decay = args.wd
    steps_per_epoch = len(train_loader)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)  

    hloss_bar = 1.0
    rloss_bar = 1.0
    trainInfoList = []
    for epoch in range(Epochs):

        model.train()

        for i, (data, target) in enumerate(train_loader):

            data = data.to(DEVICE)
            target = target.to(DEVICE)

            optimizer.zero_grad()

            output = model(data)  
            
            loss = hl_ub_loss(output, target, loss_func, noise_rate, relu)

            loss.backward()
            optimizer.step()

            # store information
            if i % 10 == 0:
                trainInfoList.append([epoch, i, loss.item()])
                print('Epoch [{}/{}], Step [{}/{}], LR {:.1e}, Loss: {:.1f}'
                      .format(epoch, Epochs, str(i).zfill(3), str(steps_per_epoch).zfill(3),
                              lr, loss.item()))

        model.eval()

        hloss, rloss, cover, avgpre, = validate_multi(val_loader, model, me)
        
        model.train()

        if hloss < hloss_bar:
            hloss_bar = hloss
            torch.save(model.state_dict(), os.path.join(
                    'models/%s/nr_%s_%s/%s_%s.pth'%(args.me, args.ra[0], args.ra[1], args.mo, args.lo)))
        
        if rloss < rloss_bar:
            rloss_bar = rloss
            # torch.save(model.state_dict(), os.path.join(
            #         'models/%s/%s_%s.pth'%(args.me, args.mo, args.lo)))

        print('hloss = {:.3f}, hloss* = {:.3f}'.format(hloss, hloss_bar))
        print('rloss = {:.3f}, rloss* = {:.3f}\n'.format(rloss,  rloss_bar))

        Writer.add_scalar('hloss', hloss, epoch)


def RLUnbiasedEST(model, train_loader, val_loader, loss_func, args, Writer):

    relu = args.relu
    noise_rate = args.nr
    me = args.me
    # set optimizer
    lr = args.lr
    Epochs = args.ep
    weight_decay = args.wd
    steps_per_epoch = len(train_loader)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)  

    hloss_bar = 1.0
    rloss_bar = 1.0
    trainInfoList = []
    for epoch in range(Epochs):

        model.train()

        for i, (data, target) in enumerate(train_loader):

            data = data.to(DEVICE)
            target = target.to(DEVICE)

            optimizer.zero_grad()

            output = model(data) 
            
            loss = rl_ub_loss(output, target, loss_func, noise_rate, relu)

            loss.backward()
            optimizer.step()

            # store information
            if i % 10 == 0:
                trainInfoList.append([epoch, i, loss.item()])
                print('Epoch [{}/{}], Step [{}/{}], LR {:.1e}, Loss: {:.1f}'
                      .format(epoch, Epochs, str(i).zfill(3), str(steps_per_epoch).zfill(3),
                              lr, loss.item()))

        model.eval()
        hloss, rloss, cover, avgpre = validate_multi(val_loader, model, me)
        model.train()
        if hloss < hloss_bar:
            hloss_bar = hloss
            # torch.save(model.state_dict(), os.path.join(
            #         'models/%s/%s_%s/%s.pth'%(args.me, args.mo, args.lo)))
        
        if rloss < rloss_bar:
            rloss_bar = rloss
            torch.save(model.state_dict(), os.path.join(
                    'models/%s/nr_%s_%s/%s_%s.pth'%(args.me, args.ra[0], args.ra[1], args.mo, args.lo)))

        print('hloss = {:.3f}, hloss* = {:.3f}'.format(hloss,  hloss_bar))
        print('rloss = {:.3f}, rloss* = {:.3f}\n'.format(rloss, rloss_bar))

        Writer.add_scalar('rloss', rloss, epoch)


def HLBiasedEST(model, train_loader, val_loader, loss_func, args, Writer):

    me = args.me
    # set optimizer
    lr = args.lr
    Epochs = args.ep
    weight_decay = args.wd
    steps_per_epoch = len(train_loader)
    optimizer = torch.optim.Adam(params=model.parameters(), lr=lr, weight_decay=weight_decay) 

    hloss_bar = 1.0
    rloss_bar = 1.0
    trainInfoList = []
    for epoch in range(Epochs):

        model.train()

        for i, (data, target) in enumerate(train_loader):

            data = data.to(DEVICE)
            target = target.to(DEVICE)

            optimizer.zero_grad()
            
            output = model(data)  

            loss = loss_func(output, target).mean()
            
            loss.backward()

            optimizer.step()

            # store information
            if i % 10 == 0:
                trainInfoList.append([epoch, i, loss.item()])
                print('Epoch [{}/{}], Step [{}/{}], LR {:.1e}, Loss: {:.1f}'
                      .format(epoch, Epochs, str(i).zfill(3), str(steps_per_epoch).zfill(3),
                              lr, loss.item()))

        model.eval()
        hloss, rloss, cover, avgpre = validate_multi(val_loader, model, me)
        model.train()

        if hloss < hloss_bar:
            hloss_bar = hloss
            torch.save(model.state_dict(), os.path.join(
                    'models/%s/nr_%s_%s/%s_%s.pth'%(args.me, args.ra[0], args.ra[1], args.mo, args.lo)))
        
        if rloss < rloss_bar:
            rloss_bar = rloss
            # torch.save(model.state_dict(), os.path.join(
            #         'models/%s/%s_%s.pth'%(args.me, args.mo, args.lo)))

        print('hloss = {:.3f}, hloss* = {:.3f}'.format(hloss, hloss_bar))
        print('rloss = {:.3f}, rloss* = {:.3f}\n'.format(rloss, rloss_bar))

        Writer.add_scalar('hloss', hloss, epoch)


def RLBiasedEST(model, train_loader, val_loader, loss_func, args, Writer):

    me = args.me
    # set optimizer
    lr = args.lr
    Epochs = args.ep
    weight_decay = args.wd
    steps_per_epoch = len(train_loader)
    optimizer = torch.optim.Adam(params=model.parameters(), lr=lr, weight_decay=weight_decay) 

    hloss_bar = 1.0
    rloss_bar = 1.0
    trainInfoList = []
    for epoch in range(Epochs):

        model.train()

        for i, (data, target) in enumerate(train_loader):

            data = data.to(DEVICE)
            target = target.to(DEVICE)

            optimizer.zero_grad()
            
            output = model(data)  

            loss = rl_biased_loss(output, target, loss_func).mean()
            
            loss.backward()

            optimizer.step()

            # store information
            if i % 10 == 0:
                trainInfoList.append([epoch, i, loss.item()])
                print('Epoch [{}/{}], Step [{}/{}], LR {:.1e}, Loss: {:.1f}'
                      .format(epoch, Epochs, str(i).zfill(3), str(steps_per_epoch).zfill(3),
                              lr, loss.item()))

        model.eval()
        hloss, rloss, cover, avgpre = validate_multi(val_loader, model, me)
        model.train()

        if hloss < hloss_bar:
            hloss_bar = hloss
            # torch.save(model.state_dict(), os.path.join(
            #         'models/%s/%s_%s.pth'%(args.me, args.mo, args.lo)))
        
        if rloss < rloss_bar:
            rloss_bar = rloss
            torch.save(model.state_dict(), os.path.join(
                    'models/%s/nr_%s_%s/%s_%s.pth'%(args.me, args.ra[0], args.ra[1], args.mo, args.lo)))

        print('hloss = {:.3f}, hloss* = {:.3f}'.format(hloss, hloss_bar))
        print('rloss = {:.3f}, rloss* = {:.3f}\n'.format(rloss, rloss_bar))

        Writer.add_scalar('rloss', rloss, epoch)




def validate_multi(val_loader, model, me):
    print("starting testing")
    output = []
    target = []
    for i, (input, tgt) in enumerate(val_loader):
        with torch.no_grad():
            opt = model(input.to(DEVICE))

        output.append(opt.cpu().detach().numpy())
        target.append(tgt.cpu().detach().numpy())

    if me in ['RLUnbiasedReLU','RLUnbiased']:
        output = np.concatenate(output)
        thr = output[:,-1]
        thr = thr[:, np.newaxis]
        output = output[:,:-1]   
        preds = -1*np.ones(output.shape,dtype=np.int64)
        preds[output>=thr] = 1
    elif me in ['HLUnbiasedReLU','HLUnbiased','HLBiased','RLBiased']:
        output = np.concatenate(output)
        preds = np.sign(output)
        preds[preds==0] = 1

    target = np.concatenate(target)
    hloss = hamming_loss(target,preds)

    target[target==-1] = 0
    preds[preds==-1] = 0

    rloss = label_ranking_loss(target, output)
    cover = compute_cover(target,output)
    avgpre = label_ranking_average_precision_score(target, output)

    print('hloss {:.3f}, rloss {:.3f}'.format(hloss, rloss))
    return hloss, rloss, cover, avgpre

def compute_cover(labels, outputs):
    n_labels = labels.shape[1]
    loss = coverage_error(labels, outputs)

    return (loss-1)/n_labels


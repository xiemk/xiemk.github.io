
import torch.nn as nn

def create_model(args):
    me = args.me
    mo = args.mo
    nc = args.nc
    dim = args.dim
    hdim = args.hdim
    if me in ['RLUnbiasedReLU','RLUnbiased']:
        if mo == 'linear':
            model = linear_model(input_dim=dim, output_dim=nc+1)
        elif mo == 'mlp':
            model = mlp_model(input_dim=dim, hidden_dim=hdim, output_dim=nc+1)
    elif me in ['HLUnbiasedReLU','HLUnbiased','HLBiased','RLBiased']:
        if mo == 'linear':
            model = linear_model(input_dim=dim, output_dim=nc)
        elif mo == 'mlp':
            model = mlp_model(input_dim=dim, hidden_dim=hdim, output_dim=nc)
        
    return model


class linear_model(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(linear_model, self).__init__()
        self.linear = nn.Linear(input_dim, output_dim)
        
    def forward(self, x):
        out = x.view(-1, self.num_flat_features(x))
        out = self.linear(out)
        #out = F.sigmoid(out)
        return out
        
    def num_flat_features(self, x):
        size = x.size()[1:]
        num_features = 1
        for s in size:
            num_features *= s
        return num_features


class mlp_model(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(mlp_model, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        out = x.view(-1, self.num_flat_features(x))
        out = self.fc1(out)
        out = self.relu1(out)
        out = self.fc2(out)
        return out

    def num_flat_features(self, x):
        size = x.size()[1:]
        num_features = 1
        for s in size:
            num_features *= s
        return num_features
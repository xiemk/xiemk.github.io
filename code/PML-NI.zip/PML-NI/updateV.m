function [ V, convg ] = updateV(fea_matrix,train_target, V,W,lambda,gamma)

max_iter_temp = 100;
convg = zeros(max_iter_temp,1);
it = 0;
L=2;
theta0 = 1;
theta1 = 1;

V1 = V;
V0 = V1;

while (it<=max_iter_temp)
    it = it+1;
    Z = V1+theta1*(1/theta0-1)*(V1-V0);
    
    svd_obj_temp_temp = (fea_matrix*(Z+W)'-train_target)'*fea_matrix;
    svd_obj_temp=svd_obj_temp_temp+lambda*(Z+W);
    obj=Z-1/L*svd_obj_temp;
    
    V0=V1;
    
    V1 = max(obj-gamma/L,0)+min(obj+gamma/L, 0);
    
    ineqL = norm(fea_matrix*(V1+W)'-train_target, 'fro')^2/2 + lambda/2*(norm(V1+W, 'fro')^2);
    ineqRtemp = norm(fea_matrix*(Z+W)'-train_target, 'fro')^2/2 + lambda/2*(norm(Z+W, 'fro')^2)-svd_obj_temp(:)'*Z(:);
    ineqR = ineqRtemp + svd_obj_temp(:)'*V1(:)+L/2*sum(sum((V1-Z).^2));
    
    while (ineqL>ineqR)
        L=L*2;
        obj=Z-1/L*svd_obj_temp;
        V1 = max(obj-gamma/L,0)+min(obj+gamma/L, 0);
        
        ineqL = norm((V1+W)*fea_matrix'-train_target', 'fro')^2/2 + lambda/2*norm(V1+W, 'fro')^2;
        ineqR=ineqRtemp+trace(svd_obj_temp'*V1)+L/2*sum(sum((V1-Z).^2));
    end
    
    theta0=theta1;
    theta1=(sqrt(theta1^4+4*theta1^2)-theta1^2)/2;
     
    convg(it,1) = ineqL+gamma*norm(V1,1);
    if it == 1
        minObj_temp = convg(it,1);
        V = V1;
    else
        if convg(it,1)<minObj_temp
            minObj_temp = convg(it,1);
            V=V1;
        end
    end
    if it>1
        if abs(convg(it,1)-convg(it-1,1))<((1e-4)*convg(it-1,1))
            %             disp(strcat('end at the ',31,num2str(k),'th iteration'));
            break;
        end
    end
end


end


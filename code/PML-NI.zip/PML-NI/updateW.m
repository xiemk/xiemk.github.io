function [ W, convergence, traceNorm ] = updateW(fea_matrix,train_target,W,V,lambda,beta)
%UPDATEW Summary of this function goes here
%   Detailed explanation goes here

max_iter_temp = 200;
theta0 = 1;
theta1 = 1;

it = 0;
W0 = W;
W1 = W0;
L=2;
convergence = zeros(max_iter_temp, 1);

while(it<max_iter_temp)
    it = it+1;
    Z = W1+theta1*(1/theta0-1)*(W1-W0);
    
    svd_obj_temp_temp = (fea_matrix*(Z+V)'-train_target)'*fea_matrix;
    svd_obj_temp=svd_obj_temp_temp+lambda*(Z+V);
    svd_obj=Z-1/L*svd_obj_temp;
    W0=W1;
    
    [W1,traceNorm] = svdThreshold(svd_obj,beta/L);
    
    ineqL = norm(fea_matrix*(W1+V)'-train_target, 'fro')^2/2 + lambda/2*(norm(W1+V, 'fro')^2);
    
    ineqRtemp = norm(fea_matrix*(Z+V)'-train_target, 'fro')^2/2 + lambda/2*(norm(Z+V, 'fro')^2)-svd_obj_temp(:)'*Z(:);
    ineqR = ineqRtemp + svd_obj_temp(:)'*W1(:)+L/2*sum(sum((W1-Z).^2));
    
    while (ineqL>ineqR)
        L=L*2;
        svd_obj=Z-1/L*svd_obj_temp;
        [W1,traceNorm]=svdThreshold(svd_obj,beta/L);
        
        ineqL = norm((W1+V)*fea_matrix'-train_target', 'fro')^2/2 + lambda/2*norm(W1+V, 'fro')^2;
        ineqR=ineqRtemp+trace(svd_obj_temp'*W1)+L/2*sum(sum((W1-Z).^2));
    end
    
    theta0=theta1;
    theta1=(sqrt(theta1^4+4*theta1^2)-theta1^2)/2;
    
    convergence(it,1)=ineqL+beta*traceNorm;
    
    %fprintf('Iteration: %d, Loss: %.3f\n', it, convergence(it,1));
    if it == 1
        minObj_temp = convergence(it,1);
        W = W1;
    else
        if convergence(it,1)<minObj_temp
            minObj_temp = convergence(it,1);
            W=W1;
        end
    end
    if it>1
        if abs(convergence(it,1)-convergence(it-1,1))<((1e-4)*convergence(it-1,1))
            %             disp(strcat('end at the ',31,num2str(k),'th iteration'));
            break;
        end
    end
end

end


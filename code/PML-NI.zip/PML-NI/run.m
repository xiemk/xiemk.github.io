
clear;

%% Experimental Setting
% Balancing parameters
lambda = 1.0;
beta=1.0;
gamma = 0.5;

% SVT parameters
threshold=10^(-12);
epsilon=10^(-8);

max_iter=20;
n_fold = 5;

dataset='image_noise';

fprintf('Dataset: %s, alpha: %d\n', dataset, 100);
path=[dataset,'.mat'];
load(path);

target(target==-1) = 0;
pLabels(pLabels==-1) = 0;

%% Cross Validation
[N, dim] = size(data);

indices = crossvalind('Kfold', data(1:N, dim),5);
result = zeros(n_fold,5);
for k=1:n_fold

test_idxs = (indices == k);
train_idxs = ~test_idxs;

train_data=data(train_idxs,:);train_target=pLabels(train_idxs,:);true_target=target(train_idxs,:);
test_data=data(test_idxs,:);test_target=target(test_idxs,:);

%% Pre-processing
[train_data, settings]=mapminmax(train_data');
test_data=mapminmax('apply',test_data',settings);
train_data(find(isnan(train_data)))=0;
test_data(find(isnan(test_data)))=0;
train_data=train_data';
test_data=test_data';

[num_train,dim]=size(train_data);
[~,num_label]=size(train_target);
[num_test,~]=size(test_data);

%% Training
fea_matrix = [train_data, ones(num_train,1)];
V = zeros(num_label,dim+1);
W = zeros(num_label,dim+1);
loss = zeros(max_iter, 1);

for t = 1:max_iter
    
    % Update W
    [ W, convergence,traceNorm] = updateW(fea_matrix,train_target,W,V,lambda,beta);
 
    % Update V
    [ V, convg ] = updateV(fea_matrix,train_target,V,W,lambda,gamma);
    
    loss(t,1) = norm(fea_matrix*(W+V)'-train_target,'fro')^2/2+lambda/2*(norm(W+V,'fro')^2)+beta*traceNorm+gamma*norm(V,1);
%     l1 = norm(fea_matrix*(W+V)'-train_target,'fro')^2/2;
%     l2 = lambda/2*(norm(W+V,'fro')^2);
%     lnorm = gamma*norm(V,1);

    if t==1
        minObj = loss(t,1);
        optW = W;
        optV = V;
    else
        if loss(t,1)<minObj
            minObj = loss(t,1);
            optW = W;
            optV = V;
        end
    end
    if t>1
        if abs(loss(t,1)-loss(t-1,1))<((1e-6)*loss(t-1,1))
             break;
        end
    end
    
    
end


%% Computing the size predictor using linear least squares model
Outputs = fea_matrix*W';
Left=Outputs;
Right=zeros(num_train,1);
for i=1:num_train
    temp=Left(i,:);
    [temp,index]=sort(temp);
    candidate=zeros(1,num_label+1);
    candidate(1,1)=temp(1)-0.1;
    for j=1:num_label-1
        candidate(1,j+1)=(temp(j)+temp(j+1))/2;
    end
    candidate(1,num_label+1)=temp(num_label)+0.1;
    miss_class=zeros(1,num_label+1);
    for j=1:num_label+1
        temp_notlabels=index(1:j-1);
        temp_labels=index(j:num_label);
        [~,false_neg]=size(setdiff(temp_notlabels,find(true_target(i,:)==0)));
        [~,false_pos]=size(setdiff(temp_labels,find(true_target(i,:)==1)));
        miss_class(1,j)=false_neg+false_pos;
    end
    [~,temp_index]=min(miss_class);
    Right(i,1)=candidate(1,temp_index);
end
Left=[Left,ones(num_train,1)];
tempvalue=(Left\Right)';
Weights_sizepre=tempvalue(1:num_label);
Bias_sizepre=tempvalue(num_label+1);
    
%% Testing
[HammingLoss,RankingLoss,OneError,Coverage,AveragePrecision] = ...
    PMLNItest( test_data,test_target,W,Weights_sizepre,Bias_sizepre);

result(k,:) = [HammingLoss,RankingLoss,OneError,Coverage,AveragePrecision];

fprintf('Cross Validation: %d, hLoss: %.3f, rLoss: %.3f, oError: %.3f, conv: %.3f, avgPre: %.3f\n', ...
            k,HammingLoss,RankingLoss,OneError,Coverage,AveragePrecision);

end







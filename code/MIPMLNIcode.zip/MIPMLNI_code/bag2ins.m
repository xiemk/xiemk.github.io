function [train_data,prototypes,means] = bag2ins(train_bags,K,par1,par2,varargin)

state = 1;
if nargin>2
    prototypes = par1;
    means = par2;
    state=0;
end

n_bags = length(train_bags);

if state
    instances = cell2mat(train_bags);
    [tmp,d] = size(instances);
    [idx,C] = kmeans(instances,K);
    K = size(C,1);
    prototypes = zeros(K,d);
    empty = [];
    means = zeros(K,1);
    for t=1:K
        cur_cluster = instances(idx==t,:);
        [n,m] = size(cur_cluster);
        if n==0
            empty = [empty,t];
            continue;
        end
        
        if n==1
            means(t) = d;
        else
            means(t) = mean(pdist(cur_cluster));
        end
        if(means(t)==0)
            means(t) = d;
        elseif(means(t)> 9999)
            means(t) = d;
        end
        
        %     dis = zeros(n,1);
        % calculate the distances from each instance to the virtual center
        %     for s = 1:m
        %         dis = dis + (cur_cluster(:,s)-C(t,s)).^2;
        %     end
        dis = sum((cur_cluster-C(t,:)).^2,2);
        
        % set the closest instance as the prototype
        [temp, prototype_idx] = min(dis);
        idxs = find(idx == t);
        prototype_id = idxs(prototype_idx);
        prototypes(t,:) = instances(prototype_id,:);
    end
    prototypes(empty,:) = [];
    means(empty,:) = [];
    
end

%% mapping multi-instance to a single instance
K = size(prototypes,1);
X = zeros(K,n_bags);
for i = 1:n_bags
    bag_instances = train_bags{i};
    n_ins = size(bag_instances,1);
    dis = zeros(K,n_ins);
    for j = 1:n_ins
        ins = bag_instances(j,:);
        dis(:,j) = sum((ins-prototypes).^2,2);
    end
    X(:,i) = min(dis,[],2);
    %     for j = 1:K
    %         dis = zeros(n_ins,1);
    %         for s = 1:d
    %             dis = dis + (bag_instances(:,s)-prototypes(j,s)).^2;
    %         end
    %         X(j,i) = min(dis);
    %     end
end
for i = 1:K
    X(i,:) = exp(-X(i,:)/means(i)^2);
end

train_data = X';

end


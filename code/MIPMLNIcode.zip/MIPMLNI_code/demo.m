
clear;

addpath(genpath('metrics'));

%set the parameters
opt.lambda = 10;
opt.beta = 0.5;
opt.gamma = 0.5;
opt.max_iter = 500;

load('sample.mat');
target(target==-1)=0;
pLabels(pLabels==-1)=0;

N = length(bags);

indices = crossvalind('Kfold', 1:N ,5);

test_idxs = (indices == 1);
train_idxs = ~test_idxs;

train_bags=bags(train_idxs);train_target=pLabels(train_idxs,:);true_target = target(train_idxs,:);
test_bags=bags(test_idxs);test_target=target(test_idxs,:);

ntr = length(train_bags);
K = round(ntr*0.5); %maximum number of prototypes

[train_data,prototypes,means] = bag2ins(train_bags,K);
%training
model = MIPMLNI_train(train_data, train_target, true_target, opt);
test_data = bag2ins(test_bags,K,prototypes,means);
%prediction
[HammingLoss,RankingLoss,OneError,Coverage,AveragePrecision] = MIPMLNI_test(test_data,test_target,model);


> README.md for code accompanying the paper "Partial Multi-Label Learning with Noisy Label Identification" 

# MIPML-NI

This repository is the official implementation of the MIPML-NI algorithm of the paper "Partial Multi-Label Learning with Noisy Label Identification" and technical details of this algorithm can be found in the paper. 

## Requirements

- MATLAB, version 2016b and higher.


